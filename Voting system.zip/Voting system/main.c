#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

// ANSI color codes for colored text
#define RESET_COLOR "\033[0m"
#define RED_COLOR "\033[31m"
#define GREEN_COLOR "\033[32m"
#define YELLOW_COLOR "\033[33m"
#define BLUE_COLOR "\033[34m"
#define MAGENTA_COLOR "\033[35m"
#define CYAN_COLOR "\033[36m"
#define BOLD_TEXT "\033[1m"
#define UNDERLINE_TEXT "\033[4m"

// Clear screen command (platform-dependent)
#ifdef _WIN32
    #define CLEAR_COMMAND "cls"
#else
    #define CLEAR_COMMAND "clear"
#endif

// Data Structures
struct Voter {
    char name[50];
    char passwordHash[65]; // SHA-256 hash length
    int hasVoted;
    struct Voter *next; // For linked list in hash table
};

struct Candidate {
    char name[50];
    int votes;
    struct Candidate *left;  // For BST
    struct Candidate *right; // For BST
};

// Optimized hash table size for voters (prime number for better distribution)
#define HASH_TABLE_SIZE 101

// Global Variables
struct Voter* voterHashTable[HASH_TABLE_SIZE];
struct Candidate* candidateRoot = NULL; // Root of BST for candidates
char adminPasswordHash[65]; // To store hashed admin password

// Function prototypes
void displayBanner();
void mainMenu();
void registerVoter();
unsigned int hash(char *str);
struct Voter* createVoter(char *name, char *password);
struct Voter* searchVoter(char *name);
void loginAndVote();
void displayCandidates(struct Candidate *root, int *count);
void castVote(struct Candidate *root, int choice, char *voterName);
void displayResults();
void insertCandidate(struct Candidate **root, char *name);
void inOrderTraversal(struct Candidate *root, struct Candidate *array[], int *index);
void quickSort(struct Candidate *array[], int low, int high);
int partition(struct Candidate *array[], int low, int high);
void swap(struct Candidate **a, struct Candidate **b);
void clearScreen();
void pauseScreen();
void printBorderedMessage(const char *message);
void printMenu();
void getInput(const char *prompt, char *input, int size);
char* hashPassword(char *password);
void saveData();
void loadData();
void helpMenu();
void resetData();
void freeVoterData();
void freeCandidateData(struct Candidate *root);
void adminHiddenFeatures();

int main() {
    // Load data from files
    loadData();

    // Initialize admin password hash
    strcpy(adminPasswordHash, hashPassword("admin"));

    displayBanner();
    mainMenu();

    // Save data to files before exiting
    saveData();

    return 0;
}

// Function to clear the screen
void clearScreen() {
    system(CLEAR_COMMAND);
}

// Function to pause the screen
void pauseScreen() {
    printf(YELLOW_COLOR "\nPress Enter to continue..." RESET_COLOR);
    getchar();
}

// Function to display the banner with watermark
void displayBanner() {
    clearScreen();
    printf(GREEN_COLOR BOLD_TEXT);
    printf("======================================================\n");
    printf("                  ONLINE VOTING SYSTEM\n\n" RESET_COLOR);
    printf(MAGENTA_COLOR "                                 ~ Made by SCR\n" RESET_COLOR);
    printf(GREEN_COLOR BOLD_TEXT);
    printf("======================================================\n\n" RESET_COLOR);
}

// Function to display a bordered message
void printBorderedMessage(const char *message) {
    printf(YELLOW_COLOR);
    printf("========================================\n");
    printf("%s\n", message);
    printf("========================================\n" RESET_COLOR);
}

// Function to display the main menu
void mainMenu() {
    int choice;
    char choiceInput[10];

    while (1) {
        clearScreen();
        displayBanner();
        printMenu();

        getInput("Enter your choice: ", choiceInput, sizeof(choiceInput));
        if (sscanf(choiceInput, "%d", &choice) != 1) {
            printf(RED_COLOR "\nInvalid input. Please enter a number.\n" RESET_COLOR);
            pauseScreen();
            continue;
        }

        switch (choice) {
            case 1:
                registerVoter();
                break;
            case 2:
                loginAndVote();
                break;
            case 3:
                displayResults();
                break;
            case 4:
                helpMenu();
                break;
            case 5:
                printf(YELLOW_COLOR "\nThank you for using the Online Voting System. Goodbye!\n" RESET_COLOR);
                // Save data before exiting
                saveData();
                exit(0);
                break;
            default:
                printf(RED_COLOR "\nInvalid choice. Please try again.\n" RESET_COLOR);
                pauseScreen();
        }
    }
}

// Function to display the main menu options
void printMenu() {
    printf(CYAN_COLOR);
    printf("\n+--------------------------------------+\n");
    printf("|              MAIN MENU               |\n");
    printf("+--------------------------------------+\n");
    printf("| 1. Register as a Voter               |\n");
    printf("| 2. Login and Vote                    |\n");
    printf("| 3. Admin: View Results               |\n");
    printf("| 4. Help                              |\n");
    printf("| 5. Exit                              |\n");
    printf("+--------------------------------------+\n\n");
    printf(RESET_COLOR);
}

// Function to display the help menu
void helpMenu() {
    clearScreen();
    printBorderedMessage("HELP MENU");
    printf("Welcome to the Online Voting System!\n\n");
    printf("1. Register as a Voter:\n");
    printf("   Allows you to register using your name and password.\n\n");
    printf("2. Login and Vote:\n");
    printf("   Login with your credentials to cast your vote.\n\n");
    printf("3. Admin: View Results:\n");
    printf("   Displays the current election results (Admin password required).\n\n");
    printf("4. Help:\n");
    printf("   Displays this help menu.\n\n");
    printf("5. Exit:\n");
    printf("   Exits the application.\n");
    pauseScreen();
}

// Improved hash function using djb2 algorithm
unsigned int hash(char *str) {
    unsigned long hashValue = 5381;
    int c;
    while ((c = *str++))
        hashValue = ((hashValue << 5) + hashValue) + tolower(c); // hash * 33 + c
    return hashValue % HASH_TABLE_SIZE;
}

// Function to create a new voter
struct Voter* createVoter(char *name, char *password) {
    struct Voter *newVoter = (struct Voter*) malloc(sizeof(struct Voter));
    if (newVoter == NULL) {
        printf(RED_COLOR "\nMemory allocation failed.\n" RESET_COLOR);
        exit(EXIT_FAILURE);
    }
    strcpy(newVoter->name, name);
    strcpy(newVoter->passwordHash, hashPassword(password));
    newVoter->hasVoted = 0;
    newVoter->next = NULL;
    return newVoter;
}

// Simple password hashing function (not secure, for demonstration)
char* hashPassword(char *password) {
    static char hash[65];
    unsigned long hashValue = 5381;
    int c;
    while ((c = *password++))
        hashValue = ((hashValue << 5) + hashValue) + c;
    sprintf(hash, "%lu", hashValue);
    return hash;
}

// Function to register a new voter
void registerVoter() {
    clearScreen();
    printBorderedMessage("VOTER REGISTRATION");

    char name[50], password[50];
    getInput("Enter your name: ", name, sizeof(name));
    getInput("Enter your password: ", password, sizeof(password));

    // Validate input
    if (strlen(name) == 0 || strlen(password) == 0) {
        printf(RED_COLOR "\nName and password cannot be empty.\n" RESET_COLOR);
        pauseScreen();
        return;
    }

    if (searchVoter(name) != NULL) {
        printf(RED_COLOR "\nVoter already registered.\n" RESET_COLOR);
        pauseScreen();
        return;
    }

    unsigned int index = hash(name);
    struct Voter *newVoter = createVoter(name, password);
    newVoter->next = voterHashTable[index];
    voterHashTable[index] = newVoter;

    printf(GREEN_COLOR "\nRegistration successful!\n" RESET_COLOR);
    pauseScreen();
}

// Function to get input from the user with a prompt
void getInput(const char *prompt, char *input, int size) {
    printf("%s", prompt);
    if (fgets(input, size, stdin) == NULL) {
        printf(RED_COLOR "\nError reading input.\n" RESET_COLOR);
        exit(EXIT_FAILURE);
    }
    input[strcspn(input, "\n")] = '\0'; // Remove newline character
}

// Function to search for a voter
struct Voter* searchVoter(char *name) {
    unsigned int index = hash(name);
    struct Voter *temp = voterHashTable[index];
    while (temp != NULL) {
        if (strcasecmp(temp->name, name) == 0)
            return temp;
        temp = temp->next;
    }
    return NULL;
}

// Function for login and voting
void loginAndVote() {
    clearScreen();
    printBorderedMessage("VOTER LOGIN");

    char name[50], password[50];
    getInput("Enter your name: ", name, sizeof(name));
    getInput("Enter your password: ", password, sizeof(password));

    struct Voter *voter = searchVoter(name);
    if (voter == NULL) {
        printf(RED_COLOR "\nVoter not found. Please register first.\n" RESET_COLOR);
        pauseScreen();
        return;
    }

    if (strcmp(voter->passwordHash, hashPassword(password)) != 0) {
        printf(RED_COLOR "\nIncorrect password.\n" RESET_COLOR);
        pauseScreen();
        return;
    }

    if (voter->hasVoted) {
        printf(RED_COLOR "\nYou have already voted.\n" RESET_COLOR);
        pauseScreen();
        return;
    }

    printf(GREEN_COLOR "\nLogin successful!\n" RESET_COLOR);
    pauseScreen();

    clearScreen();
    printBorderedMessage("CANDIDATES LIST");

    int count = 1;
    displayCandidates(candidateRoot, &count);

    char choiceInput[10];
    int choice;
    getInput("\nEnter the candidate number you want to vote for: ", choiceInput, sizeof(choiceInput));
    if (sscanf(choiceInput, "%d", &choice) != 1) {
        printf(RED_COLOR "\nInvalid input. Vote not counted.\n" RESET_COLOR);
        pauseScreen();
        return;
    }

    if (choice < 1 || choice >= count) {
        printf(RED_COLOR "\nInvalid choice. Vote not counted.\n" RESET_COLOR);
        pauseScreen();
        return;
    }

    castVote(candidateRoot, choice, name);
    voter->hasVoted = 1;
    printf(GREEN_COLOR "\nYour vote has been cast successfully!\n" RESET_COLOR);
    pauseScreen();
}

// Function to insert candidate into BST
void insertCandidate(struct Candidate **root, char *name) {
    if (*root == NULL) {
        struct Candidate *newCandidate = (struct Candidate*) malloc(sizeof(struct Candidate));
        if (newCandidate == NULL) {
            printf(RED_COLOR "\nMemory allocation failed.\n" RESET_COLOR);
            exit(EXIT_FAILURE);
        }
        strcpy(newCandidate->name, name);
        newCandidate->votes = 0;
        newCandidate->left = newCandidate->right = NULL;
        *root = newCandidate;
        return;
    }

    if (strcasecmp(name, (*root)->name) < 0)
        insertCandidate(&((*root)->left), name);
    else if (strcasecmp(name, (*root)->name) > 0)
        insertCandidate(&((*root)->right), name);
    else
        return; // Candidate already exists
}

// Function to display candidates (In-order traversal)
void displayCandidates(struct Candidate *root, int *count) {
    if (root != NULL) {
        displayCandidates(root->left, count);
        printf("   %d. %s\n", (*count)++, root->name);
        displayCandidates(root->right, count);
    }
}

// Function to cast vote to the chosen candidate
void castVote(struct Candidate *root, int choice, char *voterName) {
    struct Candidate *candidateArray[100];
    int index = 0;
    inOrderTraversal(root, candidateArray, &index);

    if (choice < 1 || choice > index) {
        printf(RED_COLOR "\nInvalid choice. Vote not counted.\n" RESET_COLOR);
        return;
    }

    candidateArray[choice - 1]->votes++;

    // Record vote timestamp
    time_t now = time(NULL);
    char *timestamp = ctime(&now);
    timestamp[strcspn(timestamp, "\n")] = '\0'; // Remove newline character

    // Save vote to file
    FILE *fp = fopen("votes.txt", "a");
    if (fp != NULL) {
        fprintf(fp, "Voter: %s, Candidate: %s, Time: %s\n", voterName, candidateArray[choice - 1]->name, timestamp);
        fclose(fp);
    } else {
        printf(RED_COLOR "\nError saving vote to file.\n" RESET_COLOR);
    }
}

// In-order traversal to store candidates in array
void inOrderTraversal(struct Candidate *root, struct Candidate *array[], int *index) {
    if (root != NULL) {
        inOrderTraversal(root->left, array, index);
        array[(*index)++] = root;
        inOrderTraversal(root->right, array, index);
    }
}

// Function to display election results
void displayResults() {
    clearScreen();
    printBorderedMessage("ADMIN LOGIN");

    // Prompt for admin password
    char password[50];
    getInput("Enter admin password: ", password, sizeof(password));

    if (strcmp(adminPasswordHash, hashPassword(password)) != 0) {
        printf(RED_COLOR "\nIncorrect admin password.\n" RESET_COLOR);
        pauseScreen();
        return;
    }

    printf(GREEN_COLOR "\nAdmin login successful!\n" RESET_COLOR);
    pauseScreen();

    clearScreen();
    printBorderedMessage("ELECTION RESULTS");

    struct Candidate *candidateArray[100];
    int index = 0;
    inOrderTraversal(candidateRoot, candidateArray, &index);

    // Sort candidates by votes in descending order
    quickSort(candidateArray, 0, index - 1);

    printf(BOLD_TEXT UNDERLINE_TEXT "\nCandidate\t\tVotes\n" RESET_COLOR);
    for (int i = 0; i < index; i++) {
        printf("   %-15s\t%d\n", candidateArray[i]->name, candidateArray[i]->votes);
    }

    printf(YELLOW_COLOR "\nPress Enter to return to main menu.\n" RESET_COLOR);
    char choiceInput[10];
    getInput("", choiceInput, sizeof(choiceInput));

    if (strcmp(choiceInput, "0") == 0) {
        char adminPass[50];
        getInput("\nEnter admin password to confirm reset: ", adminPass, sizeof(adminPass));
        if (strcmp(adminPasswordHash, hashPassword(adminPass)) == 0) {
            resetData();
            printf(GREEN_COLOR "\nAll data has been reset. System is reinitialized.\n" RESET_COLOR);
            pauseScreen();
        } else {
            printf(RED_COLOR "\nIncorrect admin password. Data reset aborted.\n" RESET_COLOR);
            pauseScreen();
        }
    } else if (strcmp(choiceInput, "42") == 0) {
        // Hidden admin feature (Easter egg)
        adminHiddenFeatures();
    }
}

// Function for admin hidden features (Easter eggs)
void adminHiddenFeatures() {
    clearScreen();
    printBorderedMessage("ADMIN SECRET MENU");

    printf("Welcome to the hidden admin panel!\n\n");
    printf("1. Add a new candidate\n");
    printf("2. Remove a candidate\n");
    printf("3. View voter list\n");
    printf("4. Back to main menu\n");

    char choiceInput[10];
    int choice;
    getInput("\nEnter your choice: ", choiceInput, sizeof(choiceInput));
    if (sscanf(choiceInput, "%d", &choice) != 1) {
        printf(RED_COLOR "\nInvalid input.\n" RESET_COLOR);
        pauseScreen();
        return;
    }

    switch (choice) {
        case 1: {
            char candidateName[50];
            getInput("\nEnter the name of the new candidate: ", candidateName, sizeof(candidateName));
            insertCandidate(&candidateRoot, candidateName);
            printf(GREEN_COLOR "\nCandidate '%s' added successfully.\n" RESET_COLOR, candidateName);
            pauseScreen();
            break;
        }
        case 2: {
            // Remove candidate functionality can be implemented here
            printf(RED_COLOR "\nFeature not implemented yet.\n" RESET_COLOR);
            pauseScreen();
            break;
        }
        case 3: {
            clearScreen();
            printBorderedMessage("REGISTERED VOTERS");

            for (int i = 0; i < HASH_TABLE_SIZE; i++) {
                struct Voter *temp = voterHashTable[i];
                while (temp != NULL) {
                    printf("   %s\n", temp->name);
                    temp = temp->next;
                }
            }
            pauseScreen();
            break;
        }
        case 4:
            // Return to main menu
            break;
        default:
            printf(RED_COLOR "\nInvalid choice.\n" RESET_COLOR);
            pauseScreen();
    }
}

// QuickSort algorithm for sorting candidates
void quickSort(struct Candidate *array[], int low, int high) {
    if (low < high) {
        int pi = partition(array, low, high);

        quickSort(array, low, pi - 1);
        quickSort(array, pi + 1, high);
    }
}

// Partition function for QuickSort
int partition(struct Candidate *array[], int low, int high) {
    int pivot = array[high]->votes;
    int i = low - 1;

    for (int j = low; j < high; j++) {
        if (array[j]->votes > pivot) {
            i++;
            swap(&array[i], &array[j]);
        }
    }
    swap(&array[i + 1], &array[high]);
    return (i + 1);
}

// Swap function
void swap(struct Candidate **a, struct Candidate **b) {
    struct Candidate *temp = *a;
    *a = *b;
    *b = temp;
}

// Function to save voter and candidate data to files
void saveData() {
    // Save voters
    FILE *fp = fopen("voters.dat", "wb");
    if (fp != NULL) {
        for (int i = 0; i < HASH_TABLE_SIZE; i++) {
            struct Voter *temp = voterHashTable[i];
            while (temp != NULL) {
                fwrite(temp, sizeof(struct Voter), 1, fp);
                temp = temp->next;
            }
        }
        fclose(fp);
    } else {
        printf(RED_COLOR "\nError saving voter data.\n" RESET_COLOR);
    }

    // Save candidates
    fp = fopen("candidates.dat", "wb");
    if (fp != NULL) {
        struct Candidate *candidateArray[100];
        int index = 0;
        inOrderTraversal(candidateRoot, candidateArray, &index);
        for (int i = 0; i < index; i++) {
            fwrite(candidateArray[i], sizeof(struct Candidate), 1, fp);
        }
        fclose(fp);
    } else {
        printf(RED_COLOR "\nError saving candidate data.\n" RESET_COLOR);
    }
}

// Function to load voter and candidate data from files
void loadData() {
    // Initialize voter hash table
    for (int i = 0; i < HASH_TABLE_SIZE; i++) {
        voterHashTable[i] = NULL;
    }

    // Load voters
    FILE *fp = fopen("voters.dat", "rb");
    if (fp != NULL) {
        struct Voter tempVoter;
        while (fread(&tempVoter, sizeof(struct Voter), 1, fp)) {
            struct Voter *newVoter = (struct Voter*) malloc(sizeof(struct Voter));
            if (newVoter == NULL) {
                printf(RED_COLOR "\nMemory allocation failed.\n" RESET_COLOR);
                exit(EXIT_FAILURE);
            }
            *newVoter = tempVoter;
            unsigned int index = hash(newVoter->name);
            newVoter->next = voterHashTable[index];
            voterHashTable[index] = newVoter;
        }
        fclose(fp);
    }

    // Load candidates
    fp = fopen("candidates.dat", "rb");
    if (fp != NULL) {
        struct Candidate tempCandidate;
        while (fread(&tempCandidate, sizeof(struct Candidate), 1, fp)) {
            insertCandidate(&candidateRoot, tempCandidate.name);
            struct Candidate *candidate = candidateRoot;
            while (candidate != NULL) {
                if (strcasecmp(candidate->name, tempCandidate.name) == 0) {
                    candidate->votes = tempCandidate.votes;
                    break;
                } else if (strcasecmp(tempCandidate.name, candidate->name) < 0) {
                    candidate = candidate->left;
                } else {
                    candidate = candidate->right;
                }
            }
        }
        fclose(fp);
    } else {
        // Initialize candidates if file doesn't exist
        insertCandidate(&candidateRoot, "Alice");
        insertCandidate(&candidateRoot, "Bob");
        insertCandidate(&candidateRoot, "Charlie");
        insertCandidate(&candidateRoot, "Diana");
        insertCandidate(&candidateRoot, "Edward");
    }
}

// Function to reset all data
void resetData() {
    // Free voter data
    freeVoterData();

    // Free candidate data
    freeCandidateData(candidateRoot);
    candidateRoot = NULL;

    // Delete data files
    remove("voters.dat");
    remove("candidates.dat");
    remove("votes.txt");

    // Reinitialize candidates
    insertCandidate(&candidateRoot, "Alice");
    insertCandidate(&candidateRoot, "Bob");
    insertCandidate(&candidateRoot, "Charlie");
    insertCandidate(&candidateRoot, "Diana");
    insertCandidate(&candidateRoot, "Edward");
}

// Function to free voter data
void freeVoterData() {
    for (int i = 0; i < HASH_TABLE_SIZE; i++) {
        struct Voter *temp = voterHashTable[i];
        while (temp != NULL) {
            struct Voter *toFree = temp;
            temp = temp->next;
            free(toFree);
        }
        voterHashTable[i] = NULL;
    }
}

// Function to free candidate data
void freeCandidateData(struct Candidate *root) {
    if (root != NULL) {
        freeCandidateData(root->left);
        freeCandidateData(root->right);
        free(root);
    }
}
